<ul>
		<li><h3><?=$secrets['title'];?></h3></li>
		<li><p><?=$secrets['text'];?></p></li>
</ul>