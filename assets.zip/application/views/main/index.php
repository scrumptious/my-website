		<div class="col col-md-5">
			<aside class="flex-item"><p class="text-justify">(1) Aside, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			</aside>
		</div>
		<div class="col col-md-5 col-md-offset-2">
			<article class="flex-item"><p class="text-justify">(2) Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
			</p>
			</article>
		</div>
	</div><!--end of row-->
	<div class="row">
		<div class="col col-md-5">
			<article>
				<p class="text-justify">(3) Article, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
			</article>
		</div>
		<div class="col col-md-5 col-md-offset-2">
			<section><ul>
				<li>(5)
				<li class="highlight"> Computer one
				<li> Second computer
				<li> Thirt one
				<li> Last Computer
			</ul></section>
		</div>
	</div><!--end of row-->
</div>


<br><br><br>
