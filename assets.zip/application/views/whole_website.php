<header class="container">
	<div class="row nav_row">
		<div class="col col-md-10 col-md-offset-2">
			<nav class="nav_bar">
				<a href="http://localhost:8080/igniter/index.php">Home</a>
				<a href="http://localhost:8080/igniter/author">Author</a>
				<a href="http://localhost:8080/igniter/shapes">Shapes Generator</a>
				<a href="http://localhost:8080/igniter/heroes">Heroes Vault</a>
				<a href="http://localhost:8080/igniter/jquery">A bit of jQuery</a>
				<a href="http://localhost:8080/igniter/contact">Get in touch</a>
			</nav>
		</div>
	</div><br><!-- end of row nav_row-->
	<div class="row">
		<div class="col col-md-6 col-md-offset-4 main_header">
			<h1>How to make things work</h1>
		</div>
	</div>
</header>
<!-- ========================= -->
<div class="row">
	<aside class="col col-md-4 col-md-offset-1 text-justify">
		<p>(1) Aside, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
	</aside>
	<article class="col col-md-4 col-md-offset-1 text-justify">
		<p>(2) Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
	</article>
</div><!--end of row-->
<!--============================= -->
<div class="row">
	<article class="col col-md-4 col-md-offset-1 text-justify">
			<p>(3) Article, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
	</article>
	<section class="col col-md-5 col-md-offset-2">
		<ul>
			<li>(5)</li>
			<li class="highlight"> Computer one</li>
			<li> Second computer</li>
			<li> Thirt one</li>
			<li> Last Computer</li>
		</ul>
	</section>
</div><!--end of row-->
