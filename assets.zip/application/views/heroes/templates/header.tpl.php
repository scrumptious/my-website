<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Page title</title>
	<link rel="stylesheet" href="<?=assets_url();?>/css/style1.css">
</head>
<body>

