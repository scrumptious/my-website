	</div>
</div>
	<div class="content">

<p>Hero deleted! (delete_complete.php)</p>

</div>