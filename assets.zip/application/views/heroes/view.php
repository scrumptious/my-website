<table style="border: 1px solid black;">
	<tr>
		<th>name</th>
		<th>level</th>
	</tr>
	<tr>
		<td><?=$hero['name'];?></td>
		<td><?=$hero['level'];?></td>
	</tr>
</table>