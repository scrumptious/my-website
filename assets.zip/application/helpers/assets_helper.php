<?php
function assets_url() {
	return base_url().'assets/';
}
?>