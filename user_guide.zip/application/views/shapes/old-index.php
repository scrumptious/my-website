<body>
<div class="container-fluid">
	<div class="row">	<!-- row1 and logo div -->
		<div class="col-md-6">
			<h1 class="logo-first-line logo-name">Shapes</h1><br>
			<h1 class="logo-second-line logo-name">generator</h1>
		</div>
		<div class="col-md-5">
			<ul class="nav-bar">
				<li><a href="#">WORK</a></li>
				<li><a href="#">ABOUT</a></li>
				<li><a href="#">CONTACT</a></li>
				<li><a href="#">RESUME</a></li>
			</ul>
		</div>
	</div>

	<div class="row"><hr></div>	<!-- row2 (hr)-->

	<div class="row">	<!-- row3 -->
		<div class="col">
			<img src="" alt="" class="img-responsive">
		</div>
		<div class="col">
			
		</div>
		<div class="col">
			
		</div>
	</div>	
	
	<div class="row">	<!-- row4 -->
		
	</div>	
</div>

