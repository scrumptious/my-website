<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
	<title><?=$title;?></title>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-tools/1.2.7/jquery.tools.min.js"></script>
	<link rel="stylesheet" href="<?=assets_url();?>css/_tabs.css">
	<link rel="stylesheet" href="<?=base_url();?>assets/css/bootstrap/_bootstrap.css">
	<link rel="stylesheet" href="<?=base_url();?>assets/css/shared.css">
	<link href="https://fonts.googleapis.com/css?family=Oswald:500" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Lora" rel="stylesheet"> 
</head>