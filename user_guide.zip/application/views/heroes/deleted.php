	</div>
</div>
<div class="content">
	<p class="error">Hero deleted</p>
	<a href="<?php echo site_url('heroes/');?>">back</a>
</div>