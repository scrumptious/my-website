			<div class="col col-md-6 col-md-offset-3">
				<p><span class="great_letter">I</span>n dark ages when knights..wait ups..I mean..<br>
				Oh right! It was meants to be about me!</p><br>

				<p><span class="great_letter">I</span>'m <strong>Ludwik Jasiurski</strong>, a junior web developer.<br>
				Passionate about programming and computers in general. <br>I do love that every day is different and there is occasion to learn something new. Thriving on challenges and natural problem solver.</p>
			</div>
		
		
	</div><!--end of row-->
</div><!--end of container-->

<br><br><br>
