		<div class="row"><hr></div>
		<div class="row">
			<div class="col-6 offset-3 col-sm-6 offset-sm-3 col-md-6 offset-md-4">
				
			<h1>Hello</h1>
			</div>
		</div>
		<div class="row text-justify">
			<div class="col-8 offset-2 col-sm-8 offset-sm-2 col-md-8 offset-md-2">
				<p class="lead"><span class="great_letter">I</span>'m <strong>Ludwik Jasiurski</strong>, web developer. Passionate about programming and computers in general.<br>
				I do love that every day is different and there is occasion to learn something new. Thriving on challenges and natural problem solver.
				My main skills so far are HTML, CSS (Sass) and JS, however I do have working knowledge of PHP, CodeIgniter etc. <br><br>

				I moved recently to Manchester which I believe is the city of great opportunities.</p>
			</div>
		</div><br>
		
<br><br><br>

<script>
	// document.querySelector('body').style.backgroundImage = 'url("../assets/imgs/background-round2.png")';
</script>