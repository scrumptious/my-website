<!-- <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title></title>
	<link href="<?=assets_url();?>css/sass-example2.css" rel="stylesheet">
	<link rel="stylesheet" href="<?=assets_url();?>css/shared.css">
	<link rel="stylesheet" href="<?=assets_url();?>css/bootstrap/_bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Oswald:500" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Lora" rel="stylesheet"> 
</head>
<body>
<div class="container">
	<div class="row nav_row">
		<div class="col col-md-offset-3">
			<nav class="nav_bar">
				<a href="index.php">Home</a>
				<a href="author">Author</a>
				<a href="shapes">Shapes Generator [project]</a>
				<a href="heroes">Heroes Vaule [project]</a>
				<a href="contact">Get in touch</a>
			</nav>
		</div>
	</div>		<br>
	<div class="row">
		<header class="main_header">
			<h1 class="col-md-6 col-md-offset-4"><?=$title;?></h1><br><br><br>
		</header> -->
		
		<div class="col col-md-6 col-md-offset-3">
			<p class="success">Your message has been sent to creator of this website. Thank you</p>
		</div>
	</div>
