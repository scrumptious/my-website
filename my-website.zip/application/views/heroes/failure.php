	</div>
</div>
	<div class="content">
		<p class="error">Hero '<?=$this->input->post('delname');?>' does NOT exist!</p>
		<?=anchor('heroes', 'back');?>
	</div>