	</div>
</div>
	<div class="content">

<p class="success">Success! Your hero has been saved in our database.</p>
<a href="<?php echo site_url('heroes/');?>">back to heroes page</a>

</div>