	</div>
</div>
<div class="content">
	<p class="error">Ups! Unable to add more heroes to a database. Please delete some heroes first.</p>
	<a href="<?php echo site_url('heroes/');?>">back</a>
</div>