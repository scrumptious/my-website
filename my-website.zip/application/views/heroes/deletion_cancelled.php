	</div>
</div>
<div class="content">
	<p class="error">Cancelled by user</p>
	<a href="<?php echo site_url('heroes/');?>">back</a>
</div>