<html>
	<head>
		<title>CodeIgniter tutorial</title>
	</head>
	<body>
		<h1><?php echo $title ?></h1>
