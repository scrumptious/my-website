</div>
    <footer class="footer">
      <div class="container">
      	<div class="row">
        	<p>2018 ©Copyright Ludwik Jasiurski</p>
      	</div>
      </div>
    </footer>
</body>
</html>